package School_Management_System;

public class Schooll {

}
